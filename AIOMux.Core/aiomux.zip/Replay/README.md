# AIOMux Replay System

Event-based replay for deterministic, auditable agent execution.

## Overview

The Replay system provides:
- **Event Recording** - Append-only JSONL logs of execution
- **Deterministic Replay** - Reconstruct runs without re-executing tools or LLMs
- **Hash Validation** - Verify integrity and detect tampering
- **Read-Only Replay** - No side effects during replay

## Architecture

```
???????????????????
? AgentRuntime    ?
???????????????????
         ?
         ?
???????????????????????      ????????????????
? RecordingAgentRuntime???????? RunRecorder  ?
???????????????????????      ????????????????
          ?                          ?
          ?                          ?
          ?                   ~/.aiomux/runs/
          ?                   ??? run1.jsonl
          ?                   ??? run2.jsonl
          ?
    ????????????
    ?  Agent   ?
    ????????????
          ?
          ?
    ????????????
    ?  Tools   ?
    ????????????

           Replay:
    ????????????????
    ? ReplayEngine ????????? ~/.aiomux/runs/runX.jsonl
    ????????????????
           ?
           ?
    ????????????????
    ? ReplayResult ?
    ? - Events     ?
    ? - Steps      ?
    ? - ToolCalls  ?
    ????????????????
```

## Core Concepts

### Run
A single execution instance with:
- Unique `RunId`
- Pipeline name and version
- Permissions snapshot
- Start/end timestamps

### RuntimeEvent
Base class for all events:
- `EventId` - Unique identifier
- `RunId` - Run this belongs to
- `Seq` - Sequence number (0-indexed)
- `Type` - Event type discriminator
- `TimestampUtc` - When it occurred
- `PayloadHash` - SHA256 of payload
- `Payload` - Event-specific data

### Event Types

1. **RunStarted** - Execution begins
2. **InputReceived** - User input captured
3. **StepCompleted** - Pipeline step finished
4. **ToolInvoked** - Tool called with arguments
5. **ToolResult** - Tool returned result
6. **RunFinished** - Execution complete

## Components

### RunRecorder

Records events to append-only JSONL files:

```csharp
var recorder = new RunRecorder();

// Start recording
var run = new Run { PipelineName = "MyAgent" };
await recorder.StartRunAsync(run);

// Record events
await recorder.RecordEventAsync(new InputReceivedEvent { ... });
await recorder.RecordEventAsync(new StepCompletedEvent { ... });

// Finish
await recorder.FinishRunAsync(success: true, finalOutput: "result");
```

Features:
- Thread-safe atomic appends
- Automatic sequence numbering
- Hash computation
- File location: `~/.aiomux/runs/<runId>.jsonl`

### ReplayEngine

Reconstructs execution from events:

```csharp
var engine = new ReplayEngine();
var result = await engine.ReplayAsync(runId, validateHashes: true);

if (result.Success)
{
    Console.WriteLine($"Pipeline: {result.PipelineName}");
    Console.WriteLine($"Steps: {result.Steps.Count}");
    Console.WriteLine($"Tool Calls: {result.ToolCalls.Count}");
    
    foreach (var step in result.Steps)
    {
        Console.WriteLine($"  {step.StepName}: {step.Output}");
    }
}
```

Features:
- Validates event ordering (0, 1, 2, ...)
- Validates payload hashes (optional)
- Read-only (never invokes tools)
- Model-free (no LLM calls)

### RecordingAgentRuntime

Wraps `IAgentRuntime` to add recording:

```csharp
var baseRuntime = new AgentRuntime(agentManager, orchestrator);
var recorder = new RunRecorder();
var recordingRuntime = new RecordingAgentRuntime(
    baseRuntime, 
    recorder, 
    enableRecording: true
);

var request = new AgentRunRequest { ... };
var result = await recordingRuntime.RunAsync(request);
```

## Storage Format

### JSONL Structure

Each line is a complete JSON event:

```jsonl
{"EventId":"e1","RunId":"r1","Seq":0,"Type":"RunStarted","TimestampUtc":"...","PayloadHash":"...","Payload":{...}}
{"EventId":"e2","RunId":"r1","Seq":1,"Type":"InputReceived","TimestampUtc":"...","PayloadHash":"...","Payload":{...}}
{"EventId":"e3","RunId":"r1","Seq":2,"Type":"StepCompleted","TimestampUtc":"...","PayloadHash":"...","Payload":{...}}
```

### Directory Structure

```
~/.aiomux/
??? runs/
    ??? 12345678-1234-1234-1234-123456789abc.jsonl
    ??? 87654321-4321-4321-4321-210987654321.jsonl
    ??? ...
```

## CLI Commands

### List Runs

```bash
dotnet run --project AIOMux.Local -- runs list
```

Shows all recorded runs with status and event counts.

### Show Run Details

```bash
dotnet run --project AIOMux.Local -- runs show <runId>
```

Displays run metadata (pipeline, start/end times, success status).

### Replay Run

```bash
dotnet run --project AIOMux.Local -- runs replay <runId>
```

Reconstructs and displays the full event timeline.

### Demo: NotesSkill + Replay

```bash
dotnet run --project AIOMux.Local -- demo notes add --text "Test note" --replay
```

Executes NotesSkill with recording and immediately replays. See [DEMO_REPLAY.md](DEMO_REPLAY.md) for details.

## Use Cases

### 1. Debugging
Replay a failed run to see exactly where it went wrong without re-executing.

### 2. Auditing
Review what tools were called, with what arguments, and what they returned.

### 3. Testing
Verify pipeline determinism by comparing multiple runs.

### 4. Performance Analysis
Examine step durations to identify bottlenecks.

### 5. Offline Analysis
Inspect runs when models or external services are unavailable.

### 6. Compliance
Maintain immutable audit logs of all agent operations.

## Validation

### Sequence Validation
Events must be numbered sequentially (0, 1, 2, ...) with no gaps.

### Hash Validation
For each event, `PayloadHash = SHA256(JSON.serialize(Payload))`.

If a hash doesn't match, replay fails with:
```
Hash validation failed: Hash mismatch for event 5 (type: StepCompleted)
```

### Event Structure Validation
- First event must be `RunStarted`
- Events must have valid timestamps
- Required fields must be present

## Determinism

### What Replay CAN Verify
? Step outputs are consistent  
? Tool arguments are identical  
? Tool results match  
? Event sequence is correct  

### What Replay CANNOT Verify
? LLM behavior (model not called)  
? External state changes (no side effects)  
? Time-dependent behavior (uses recorded timestamps)  
? Random behavior (uses recorded outputs)  

## Best Practices

### 1. Enable Recording in Development
Use `RecordingAgentRuntime` during testing to capture execution traces.

### 2. Validate Hashes in CI/CD
Run replay with hash validation in tests to detect non-determinism.

### 3. Archive Run Logs
Keep logs for auditing and compliance requirements.

### 4. Design Deterministic Pipelines
Avoid randomness and time-dependent behavior in pipeline steps.

### 5. Use Meaningful RunIds
Consider using descriptive IDs or tags in metadata.

## Permissions

Replay is **read-only** by design:
- No tools are invoked
- No files are written (except during recording)
- No network calls are made
- No model calls are made

This ensures replay is safe and has no side effects.

## Performance

### Recording Overhead
- Minimal: ~1-2ms per event
- Atomic file appends
- No blocking during execution

### Replay Performance
- Fast: O(n) where n = number of events
- In-memory reconstruction
- No I/O except initial file read

### Storage
- ~100-500 bytes per event
- JSONL format compresses well
- Consider rotating old logs

## Testing

Run replay system tests:

```bash
dotnet test AIOMux.Core.Tests --filter "Replay"
```

Tests cover:
- Event recording
- Sequence enforcement
- Hash validation
- Timeline reconstruction
- Incomplete run handling

## Example: Complete Workflow

```bash
# 1. Execute with recording (demo command)
dotnet run --project AIOMux.Local -- demo notes add --text "Test" --replay

# Output shows:
#   RunId: 12345678-...
#   NoteId: abcd1234-...
#   Run Log: ~/.aiomux/runs/12345678-....jsonl

# 2. List all runs
dotnet run --project AIOMux.Local -- runs list

# 3. Show specific run
dotnet run --project AIOMux.Local -- runs show 12345678-...

# 4. Replay it
dotnet run --project AIOMux.Local -- runs replay 12345678-...

# 5. Verify note was saved
dotnet run --project AIOMux.Local -- notes list
```

## Limitations

1. **Determinism Required** - Non-deterministic pipelines can't be replayed accurately
2. **No Model Calls** - Replay can't verify LLM behavior
3. **Local Only** - No network calls during replay
4. **Storage Growth** - JSONL files accumulate over time

## Future Enhancements

- [ ] Compression for old run logs
- [ ] Replay with model verification (optional)
- [ ] Diff two runs to compare behavior
- [ ] Replay with breakpoints/stepping
- [ ] Export to other formats (Markdown, HTML)
- [ ] Replay UI (web-based viewer)

## Integration

To add replay to your own agents:

```csharp
// 1. Wrap your runtime
var baseRuntime = new AgentRuntime(agentManager, orchestrator);
var recorder = new RunRecorder();
var recordingRuntime = new RecordingAgentRuntime(baseRuntime, recorder);

// 2. Execute (events recorded automatically)
var result = await recordingRuntime.RunAsync(request);

// 3. Later, replay
var engine = new ReplayEngine();
var replay = await engine.ReplayAsync(result.RunId);
```

That's it! No changes needed to your agents or tools.

## License

Part of AIOMux, licensed under MIT License.
